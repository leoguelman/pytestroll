# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['pytestroll']

package_data = \
{'': ['*']}

install_requires = \
['joblib>=1.1.0,<2.0.0', 'numpy>=1.22.4,<2.0.0', 'pandas>=1.4.2,<2.0.0']

extras_require = \
{':python_full_version >= "3.8.3" and python_version < "3.11"': ['scipy>=1.8.1,<2.0.0']}

setup_kwargs = {
    'name': 'pytestroll',
    'version': '0.1.0',
    'description': 'Profit Maximizing A/B Testing',
    'long_description': '# pytestroll\n\nProfit Maximizing A/B Testing.\n\n`pytestroll` implements the methods in the paper [Test & Roll: Profit-Maximizing A/B Tests](https://arxiv.org/abs/1811.00457) by Elea McDonnell Feit and Ron Berman.\n\n\n## Installation\n\n```bash\n$ pip install pytestroll\n```\n\n## Usage\n\n`pytestroll` computes the profit-maximizing test size for a 2-armed A/B test, along with other functionality required to reproduce the paper results and examples. \n\n```python\nfrom pytestroll.pytestroll import NHST, TestRoll\nimport numpy as np\n    \n    \nmu = 0.68\nsigma = 0.03\nN = 100000\n\n# Profit-maximizing\ntr = TestRoll(N = N, s = np.sqrt(mu*(1-mu)), mu = mu, sigma = sigma)\nn_star = tr.tr_size_nn()\nprint("Test & Roll samples:", n_star, \'\\n\')\n\n# Compare to standard Null Hypothesis Significance Test paradigm\n\nd = 0.68*0.02 # 2% lift \n\nnht = NHST(s=np.sqrt(mu*(1-mu)), d=d)\nn_nht = nht.nht_size_nn()\nprint("NHST Samples:", n_nht, \'\\n\')\n```\n\n## Contributing\n\nInterested in contributing? Check out the contributing guidelines. Please note that this project is released with a Code of Conduct. By contributing to this project, you agree to abide by its terms.\n\n## License\n\n`pytestroll` was created by Leo Guelman. It is licensed under the terms of the MIT license.\n\n## Credits\n\n`pytestroll` was created with [`cookiecutter`](https://cookiecutter.readthedocs.io/en/latest/) and the `py-pkgs-cookiecutter` [template](https://github.com/py-pkgs/py-pkgs-cookiecutter).\n',
    'author': 'Leo Guelman',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'extras_require': extras_require,
    'python_requires': '>=3.8.3,<4.0.0',
}


setup(**setup_kwargs)
